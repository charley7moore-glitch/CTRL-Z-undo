# Undo Coin ($UNDO) – Official Meme Token Website

A simple, static landing page for **Undo Coin**, the meme token that lets you press CTRL+Z on your crypto losses.

## Features
- 🚀 One-page static site
- 🪙 Token info (supply, tax, wallet)
- 🔗 Direct Uniswap buy link
- ⚡ Ready for deployment on Vercel / Netlify / Surge

## Deployment
Upload this repo to GitHub, then import it into [Vercel](https://vercel.com/new) or drag it into [Netlify Drop](https://app.netlify.com/drop) to go live instantly.

---
© 2025 Undo Coin. Meme responsibly.
